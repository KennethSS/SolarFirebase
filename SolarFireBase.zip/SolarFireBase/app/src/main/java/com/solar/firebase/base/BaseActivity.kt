package com.solar.firebase.base

import android.app.ProgressDialog
import androidx.appcompat.app.AppCompatActivity


abstract class BaseActivity : AppCompatActivity() {
    private val _progressDialog: ProgressDialog by lazy {
        ProgressDialog(this)
    }

    fun showProgress() {
        _progressDialog.show()
    }

    fun dismissProgress() {
        if (_progressDialog.isShowing)
            _progressDialog.dismiss()
    }
}